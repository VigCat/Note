package com.civet.note.web;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.civet.note.entity.Note;

//@org.springframework.stereotype.Controller
/***
 * 
 * @author ChengJun
 *
 */
@Controller
@RequestMapping("/test") // 这个要使用组件扫描
public class TestHandler {

	@SuppressWarnings("unused")
	@RequestMapping("/test")
	public ModelAndView testHandler() {
		// 调用service 做业务实现
		List<String> list = new ArrayList<String>();

		for (int i = 0; i < 10; i++) {
//			list.add(String.valueOf(i * 5));
			System.out.println("test");
		}
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("list", list);
		modelAndView.setViewName("/page/index.jsp");
		// 相当于request.setAttribute()
		Note note=new Note();
		return modelAndView;
	}

}
